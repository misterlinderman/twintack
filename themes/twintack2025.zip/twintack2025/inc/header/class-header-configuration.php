<?php
/**
 * Header Configuration Class
 */
class TwinTack_Header_Configuration {
    private static $instance = null;
    
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        add_action('acf/init', array($this, 'register_header_fields'));
    }

    public function register_header_fields() {
        if (function_exists('acf_add_local_field_group')) {
            acf_add_local_field_group(array(
                'key' => 'group_header_configuration',
                'title' => 'Header Configuration',
                'fields' => array(
                    array(
                        'key' => 'field_header_configuration',
                        'label' => 'Header Layout',
                        'name' => 'header_configuration',
                        'type' => 'flexible_content',
                        'layouts' => array(
                            'image_header' => array(
                                'key' => 'layout_image_header',
                                'name' => 'image_header',
                                'label' => 'Image Header',
                                'sub_fields' => array(
                                    // Your existing image header fields
                                )
                            ),
                            'video_header' => array(
                                'key' => 'layout_video_header',
                                'name' => 'video_header',
                                'label' => 'Video Header',
                                'sub_fields' => array(
                                    // Your existing video header fields
                                )
                            )
                        )
                    )
                ),
                'location' => array(
                    array(
                        array(
                            'param' => 'post_type',
                            'operator' => '==',
                            'value' => 'page',
                        ),
                    ),
                    array(
                        array(
                            'param' => 'taxonomy',
                            'operator' => '==',
                            'value' => 'product_cat',
                        ),
                    ),
                ),
            ));
        }
    }
}

// Initialize the class
add_action('init', array('TwinTack_Header_Configuration', 'get_instance')); 
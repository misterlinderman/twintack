<?php
/**
 * Theme functions and definitions
 */

// Autoloader for theme classes
spl_autoload_register(function ($class_name) {
    $class_files = array(
        'Theme_Bootstrap' => '/inc/core/class-theme-bootstrap.php',
        'Theme_Assets' => '/inc/core/class-assets.php',
        'Theme_Setup' => '/inc/class-theme-setup.php',
        'Template_Utilities' => '/inc/utilities/class-template-utilities.php',
        'Theme_Customizer' => '/inc/customizer/class-theme-customizer.php',
        'WooCommerce_Integration' => '/inc/woocommerce/class-woocommerce-integration.php',
        'ACF_Integration' => '/inc/acf/class-acf-integration.php',
        'Theme_Hooks' => '/inc/hooks/class-theme-hooks.php',
        'Header_Configuration' => '/inc/class-header-configuration.php'
        'Header_Blocks' => '/inc/header/class-header-blocks.php',
        'Header_Render' => '/inc/header/class-header-render.php',
    );

    if (isset($class_files[$class_name])) {
        require_once get_template_directory() . $class_files[$class_name];
    }
});

// Initialize theme components
Theme_Setup::get_instance();
Theme_Customizer::get_instance();
WooCommerce_Integration::get_instance();
ACF_Integration::get_instance();
Theme_Hooks::get_instance();
Header_Configuration::get_instance();
Header_Blocks::get_instance();
Header_Render::get_instance();
Theme_Bootstrap::get_instance();
Theme_Assets::get_instance();

// Define theme constants
define('TWINTACK_VERSION', wp_get_theme()->get('Version'));
define('TWINTACK_TEMPLATE_DIR', get_template_directory());
define('TWINTACK_TEMPLATE_URI', get_template_directory_uri());


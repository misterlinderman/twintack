<?php
/**
 * Product template handling
 *
 * @package TwinTack
 */

namespace TwinTack\Product;

class Product_Template {
    private $template_path;

    public function __construct() {
        $this->template_path = get_template_directory() . '/template-parts/product/';
    }

    public function render($template_name, $data = []) {
        $template_file = $this->template_path . $template_name . '.php';
        
        if (!file_exists($template_file)) {
            return;
        }

        extract($data);
        include $template_file;
    }
}
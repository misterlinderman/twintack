<?php
/**
 * Category display handling
 *
 * @package TwinTack
 */

namespace TwinTack\WooCommerce;

class Category_Display {
    private static $instance = null;

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->init_hooks();
    }

    private function init_hooks() {
        add_action('woocommerce_before_main_content', [$this, 'category_header'], 5);
        add_action('woocommerce_before_shop_loop', [$this, 'category_navigation'], 5);
    }

    public function category_header() {
        if (!is_product_category()) {
            return;
        }

        $category = get_queried_object();
        $category_class = $category->slug . '-theme';
        
        echo '<div class="category-hero ' . esc_attr($category_class) . '">';
        echo '<div class="container">';
        echo '<h1>' . esc_html($category->name) . '</h1>';
        if ($category->description) {
            echo '<div class="category-description">' . wp_kses_post($category->description) . '</div>';
        }
        echo '</div>';
        echo '</div>';
    }

    public function category_navigation() {
        if (!is_product_category()) {
            return;
        }

        $category = get_queried_object();
        $menu_location = $category->slug;
        
        if (has_nav_menu($menu_location)) {
            echo '<div class="category-navigation ' . esc_attr($category->slug) . '-category-nav">';
            echo '<div class="container">';
            wp_nav_menu([
                'theme_location' => $menu_location,
                'container_class' => 'category-menu',
                'menu_class' => 'category-menu-items'
            ]);
            echo '</div>';
            echo '</div>';
        }
    }
}
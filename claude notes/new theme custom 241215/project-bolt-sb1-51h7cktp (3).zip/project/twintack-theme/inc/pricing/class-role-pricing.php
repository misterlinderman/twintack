<?php
/**
 * Role-based pricing core functionality
 *
 * @package TwinTack
 */

namespace TwinTack\Pricing;

class Role_Pricing {
    private static $instance = null;
    private $roles;
    private $display;

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->roles = [
            'brand_partner' => 'Brand Partner',
            'sales_rep' => 'Sales Representative',
            'event_customer' => 'Event Customer'
        ];
        
        $this->display = new Role_Pricing_Display($this->roles);
        $this->init_hooks();
    }

    private function init_hooks() {
        add_action('init', [$this, 'register_roles']);
        add_action('woocommerce_product_options_pricing', [$this->display, 'add_price_fields']);
        add_action('woocommerce_process_product_meta', [$this->display, 'save_price_fields']);
        add_filter('woocommerce_product_get_price', [$this, 'modify_price'], 10, 2);
    }

    public function register_roles() {
        foreach ($this->roles as $role_id => $role_name) {
            add_role($role_id, $role_name, ['read' => true]);
        }
    }

    public function modify_price($price, $product) {
        if (!is_user_logged_in()) {
            return $price;
        }

        $user = wp_get_current_user();
        foreach ($this->roles as $role_id => $role_name) {
            if ($this->user_has_role($user, $role_id)) {
                $role_price = $this->get_role_price($product, $role_id);
                if ($role_price !== '' && $role_price > 0) {
                    return $role_price;
                }
            }
        }
        return $price;
    }

    private function user_has_role($user, $role) {
        return in_array($role, $user->roles);
    }

    private function get_role_price($product, $role_id) {
        return get_post_meta($product->get_id(), "_${role_id}_price", true);
    }
}
<?php
/**
 * Role-based pricing display handling
 *
 * @package TwinTack
 */

namespace TwinTack\Pricing;

class Role_Pricing_Display {
    private $roles;

    public function __construct(array $roles) {
        $this->roles = $roles;
    }

    public function add_price_fields() {
        foreach ($this->roles as $role_id => $role_name) {
            $this->add_role_price_field($role_id, $role_name);
        }
    }

    private function add_role_price_field($role_id, $role_name) {
        woocommerce_wp_text_input([
            'id' => "_${role_id}_price",
            'label' => "$role_name Price",
            'data_type' => 'price',
            'desc_tip' => true,
            'description' => "Enter the price for $role_name accounts"
        ]);
    }

    public function save_price_fields($post_id) {
        foreach ($this->roles as $role_id => $role_name) {
            $this->save_role_price($post_id, $role_id);
        }
    }

    private function save_role_price($post_id, $role_id) {
        $price_field = "_${role_id}_price";
        if (isset($_POST[$price_field])) {
            update_post_meta($post_id, $price_field, wc_clean($_POST[$price_field]));
        }
    }
}
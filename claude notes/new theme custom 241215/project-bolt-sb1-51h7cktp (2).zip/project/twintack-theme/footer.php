<?php
/**
 * The footer template
 *
 * @package TwinTack
 */
?>
    <footer id="colophon" class="site-footer">
        <div class="container">
            <div class="footer-widgets">
                <?php dynamic_sidebar('footer-1'); ?>
            </div>
            <div class="site-info">
                <?php echo esc_html(sprintf('© %d %s', date('Y'), get_bloginfo('name'))); ?>
            </div>
        </div>
    </footer>
</div><!-- #page -->

<?php wp_footer(); ?>
</body>
</html>
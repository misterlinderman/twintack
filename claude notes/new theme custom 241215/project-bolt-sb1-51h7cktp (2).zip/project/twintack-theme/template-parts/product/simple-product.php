<?php
/**
 * Template part for displaying simple products
 *
 * @package TwinTack
 */

defined('ABSPATH') || exit;
?>

<div class="product-simple">
    <a href="<?php echo esc_url($product->get_permalink()); ?>">
        <?php echo $product->get_image('woocommerce_thumbnail'); ?>
        <h3><?php echo esc_html($product->get_title()); ?></h3>
        <span class="price"><?php echo wp_kses_post($product->get_price_html()); ?></span>
    </a>
</div>
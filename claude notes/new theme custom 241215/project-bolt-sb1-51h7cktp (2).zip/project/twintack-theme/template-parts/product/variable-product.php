<?php
/**
 * Template part for displaying variable products
 *
 * @package TwinTack
 */

defined('ABSPATH') || exit;

foreach ($variations as $variation): ?>
    <div class="product-variant">
        <a href="<?php echo esc_url(add_query_arg('default_variant', $variation['variation_id'], $product->get_permalink())); ?>">
            <?php echo wp_get_attachment_image($variation['image_id'], 'woocommerce_thumbnail'); ?>
            <h3><?php echo esc_html($product->get_title() . ' - ' . implode(', ', $variation['attributes'])); ?></h3>
            <span class="price"><?php echo wp_kses_post($variation['price_html']); ?></span>
        </a>
    </div>
<?php endforeach; ?>
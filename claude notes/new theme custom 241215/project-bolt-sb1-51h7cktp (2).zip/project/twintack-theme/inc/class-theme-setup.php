<?php
/**
 * Theme setup and configuration
 *
 * @package TwinTack
 */

namespace TwinTack;

class Theme_Setup {
    private static $instance = null;

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->init_hooks();
    }

    private function init_hooks() {
        add_action('after_setup_theme', [$this, 'setup_theme']);
        add_action('widgets_init', [$this, 'register_sidebars']);
        add_action('wp_enqueue_scripts', [$this, 'enqueue_assets']);
    }

    public function setup_theme() {
        load_theme_textdomain('twintack', get_template_directory() . '/languages');

        add_theme_support('automatic-feed-links');
        add_theme_support('title-tag');
        add_theme_support('post-thumbnails');
        add_theme_support('custom-logo');
        add_theme_support('woocommerce');

        register_nav_menus([
            'primary' => esc_html__('Primary Menu', 'twintack'),
            'baseball' => esc_html__('Baseball Category Menu', 'twintack'),
            'fishing' => esc_html__('Fishing Category Menu', 'twintack')
        ]);
    }

    public function register_sidebars() {
        register_sidebar([
            'name' => esc_html__('Footer Widget Area', 'twintack'),
            'id' => 'footer-1',
            'description' => esc_html__('Add widgets here to appear in the footer.', 'twintack'),
            'before_widget' => '<section id="%1$s" class="widget %2$s">',
            'after_widget' => '</section>',
            'before_title' => '<h2 class="widget-title">',
            'after_title' => '</h2>',
        ]);
    }

    public function enqueue_assets() {
        wp_enqueue_style('twintack-style', get_stylesheet_uri(), [], wp_get_theme()->get('Version'));
        
        if (is_product_category('baseball')) {
            wp_enqueue_style('twintack-baseball', get_template_directory_uri() . '/assets/css/baseball.css', [], wp_get_theme()->get('Version'));
        } elseif (is_product_category('fishing')) {
            wp_enqueue_style('twintack-fishing', get_template_directory_uri() . '/assets/css/fishing.css', [], wp_get_theme()->get('Version'));
        }
    }
}
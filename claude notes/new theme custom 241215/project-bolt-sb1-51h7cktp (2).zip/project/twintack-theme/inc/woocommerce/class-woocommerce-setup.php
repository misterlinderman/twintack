<?php
/**
 * WooCommerce specific setup
 *
 * @package TwinTack
 */

namespace TwinTack\WooCommerce;

class WooCommerce_Setup {
    private static $instance = null;

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->init_hooks();
    }

    private function init_hooks() {
        add_action('after_setup_theme', [$this, 'setup_woocommerce']);
        add_filter('woocommerce_enqueue_styles', '__return_empty_array');
    }

    public function setup_woocommerce() {
        add_theme_support('wc-product-gallery-zoom');
        add_theme_support('wc-product-gallery-lightbox');
        add_theme_support('wc-product-gallery-slider');
    }
}
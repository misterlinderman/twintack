<?php
namespace TwinTack\Pricing;

class Role_Pricing {
    private static $instance = null;
    private $roles;

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->roles = [
            'brand_partner' => 'Brand Partner',
            'sales_rep' => 'Sales Representative',
            'event_customer' => 'Event Customer'
        ];
        
        $this->init_hooks();
    }

    private function init_hooks() {
        add_action('init', [$this, 'register_roles']);
        add_action('woocommerce_product_options_pricing', [$this, 'add_price_fields']);
        add_action('woocommerce_process_product_meta', [$this, 'save_price_fields']);
        add_filter('woocommerce_product_get_price', [$this, 'modify_price'], 10, 2);
    }

    public function register_roles() {
        foreach ($this->roles as $role_id => $role_name) {
            add_role($role_id, $role_name, ['read' => true]);
        }
    }

    public function add_price_fields() {
        foreach ($this->roles as $role_id => $role_name) {
            $this->add_role_price_field($role_id, $role_name);
        }
    }

    private function add_role_price_field($role_id, $role_name) {
        woocommerce_wp_text_input([
            'id' => "_${role_id}_price",
            'label' => "$role_name Price",
            'data_type' => 'price',
            'desc_tip' => true,
            'description' => "Enter the price for $role_name accounts"
        ]);
    }

    public function save_price_fields($post_id) {
        foreach ($this->roles as $role_id => $role_name) {
            $this->save_role_price($post_id, $role_id);
        }
    }

    private function save_role_price($post_id, $role_id) {
        $price_field = "_${role_id}_price";
        if (isset($_POST[$price_field])) {
            update_post_meta($post_id, $price_field, wc_clean($_POST[$price_field]));
        }
    }

    public function modify_price($price, $product) {
        if (!is_user_logged_in()) return $price;

        $user = wp_get_current_user();
        foreach ($this->roles as $role_id => $role_name) {
            if ($this->user_has_role($user, $role_id)) {
                $role_price = $this->get_role_price($product, $role_id);
                if ($role_price !== '' && $role_price > 0) {
                    return $role_price;
                }
            }
        }
        return $price;
    }

    private function user_has_role($user, $role) {
        return in_array($role, $user->roles);
    }

    private function get_role_price($product, $role_id) {
        return get_post_meta($product->get_id(), "_${role_id}_price", true);
    }
}
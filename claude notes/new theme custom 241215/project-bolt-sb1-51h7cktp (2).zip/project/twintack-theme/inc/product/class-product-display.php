<?php
namespace TwinTack\Product;

class Product_Display {
    private static $instance = null;

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->init_hooks();
    }

    private function init_hooks() {
        add_action('woocommerce_before_shop_loop', [$this, 'modify_category_display'], 10);
        add_filter('woocommerce_product_get_default_attributes', [$this, 'set_default_variant'], 10, 2);
        add_action('wp_enqueue_scripts', [$this, 'enqueue_styles']);
    }

    public function modify_category_display() {
        if (!is_product_category()) return;

        $this->remove_default_hooks();
        $this->add_custom_hooks();
    }

    private function remove_default_hooks() {
        remove_action('woocommerce_before_shop_loop_item', 'woocommerce_template_loop_product_link_open', 10);
        remove_action('woocommerce_after_shop_loop_item', 'woocommerce_template_loop_product_link_close', 5);
    }

    private function add_custom_hooks() {
        add_action('woocommerce_before_shop_loop_item', [$this, 'render_product_display'], 10);
    }

    public function render_product_display() {
        global $product;
        if ($product->is_type('variable')) {
            $this->render_variable_product($product);
        } else {
            $this->render_simple_product($product);
        }
    }

    private function render_variable_product($product) {
        $template = new Product_Template_Loader();
        $template->render('variable-product', [
            'variations' => $product->get_available_variations(),
            'product' => $product
        ]);
    }

    private function render_simple_product($product) {
        $template = new Product_Template_Loader();
        $template->render('simple-product', ['product' => $product]);
    }

    public function set_default_variant($default_attributes, $product) {
        $variant_id = get_query_var('default_variant');
        if (!$variant_id) return $default_attributes;

        $variation = wc_get_product($variant_id);
        if ($variation && $variation->get_type() === 'variation') {
            return $variation->get_attributes();
        }

        return $default_attributes;
    }

    public function enqueue_styles() {
        wp_add_inline_style('twintack-style', $this->get_inline_styles());
    }

    private function get_inline_styles() {
        return '
            .product-variant {
                margin-bottom: 2em;
                transition: transform 0.3s ease;
            }
            .product-variant:hover {
                transform: translateY(-5px);
            }
        ';
    }
}
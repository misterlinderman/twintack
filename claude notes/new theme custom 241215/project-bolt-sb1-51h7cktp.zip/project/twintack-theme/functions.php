<?php
/**
 * TwinTack Theme functions and definitions
 *
 * @package TwinTack
 */

defined('ABSPATH') || exit;

// Autoloader for theme classes
spl_autoload_register(function ($class) {
    $prefix = 'TwinTack\\';
    $base_dir = get_template_directory() . '/inc/';

    if (strpos($class, $prefix) !== 0) {
        return;
    }

    $relative_class = substr($class, strlen($prefix));
    $file = $base_dir . str_replace('\\', '/', strtolower($relative_class)) . '.php';

    if (file_exists($file)) {
        require $file;
    }
});

// Initialize core functionality
add_action('after_setup_theme', function() {
    // Initialize Product Display
    TwinTack\Product\Product_Display::get_instance();
    
    // Initialize Role Pricing
    TwinTack\Pricing\Role_Pricing::get_instance();
});